"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import AdminGuard from "@/components/AdminGuard";
import { supabase } from "@/lib/supabaseClient";
import { formatPrice } from "@/lib/whatsapp";
import { cabeceraAdmin } from "@/lib/verificarAdmin";
import DetallePedidoRecibido from "@/components/DetallePedidoRecibido";
import { aplicarBusqueda } from "@/lib/buscar";

// Pega el texto del pedido tal como sale de la web del proveedor, la app
// interpreta cada línea y busca la foto. Es lo mismo que se hacía a mano en
// el chat, ahora en un paso.
//
// El pedido queda en "camino": aparece sin precio en /proximamente para
// que el cliente se anticipe. Al llegar, un botón carga todo a Productos
// con stock, precio y foto.
function PedidoProveedor() {
  const [vista, setVista] = useState("nuevo"); // nuevo | camino | recibidos
  const [texto, setTexto] = useState("");
  const [flete, setFlete] = useState("");
  const [interpretando, setInterpretando] = useState(false);
  const [items, setItems] = useState([]);
  const [subtotal, setSubtotal] = useState(0);
  const [guardando, setGuardando] = useState(false);
  const [pedidos, setPedidos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [recibiendoId, setRecibiendoId] = useState(null);
  const [borrandoId, setBorrandoId] = useState(null);
  const [subiendoFotoLinea, setSubiendoFotoLinea] = useState(null);

  // Foto de un producto del pedido. Hace falta sobre todo en los nuevos:
  // si el proveedor no tiene una foto que coincida con seguridad, preferimos
  // que la saques vos antes que mostrar la de otro producto.
  async function subirFotoLinea(linea, archivo) {
    if (!archivo) return;
    setSubiendoFotoLinea(linea.id);
    try {
      const nombreArchivo = `pedido-linea-${linea.id}-${Date.now()}.jpg`;
      const { error } = await supabase.storage
        .from("fotos-productos")
        .upload(nombreArchivo, archivo, { contentType: archivo.type || "image/jpeg" });
      if (error) throw new Error(error.message);

      const { data } = supabase.storage.from("fotos-productos").getPublicUrl(nombreArchivo);

      const { error: errUpd } = await supabase
        .from("lineas_pedido_proveedor")
        .update({ imagen_url: data.publicUrl })
        .eq("id", linea.id);
      if (errUpd) throw new Error(errUpd.message);

      setItemsEditando((prev) =>
        prev.map((it) => (it.id === linea.id ? { ...it, imagen_url: data.publicUrl } : it))
      );
      cargarPedidos();
    } catch (e) {
      alert("No se pudo subir la foto: " + e.message);
    } finally {
      setSubiendoFotoLinea(null);
    }
  }

  function fotoDeLinea(l) {
    return l.imagen_url || l.Productos?.imagen_url || null;
  }
  const [editando, setEditando] = useState(null); // pedido en edición
  const [itemsEditando, setItemsEditando] = useState([]);
  const [fleteEditando, setFleteEditando] = useState(0);

  async function cargarPedidos() {
    setLoading(true);
    const { data } = await supabase
      .from("pedidos_proveedor")
      .select("*, lineas_pedido_proveedor(id, nombre, nombre_normalizado, producto_id, cantidad, precio_unitario, tipo, costo_real, nota, imagen_url, aplicada, Productos(nombre, imagen_url, precio, costo))")
      .order("created_at", { ascending: false });
    setPedidos(data || []);
    setLoading(false);
  }

  const [buscandoFotos, setBuscandoFotos] = useState(false);
  const [avisoFotos, setAvisoFotos] = useState("");

  // Completa las fotos que faltan buscándolas en el proveedor, y copia a
  // nuestro servidor las que todavía se muestran desde su página. Se llama
  // sola al abrir esta pantalla: si el proveedor estaba caído, apenas
  // vuelve las fotos se completan sin que haya que hacer nada.
  async function completarFotos(conAviso) {
    if (typeof navigator !== "undefined" && !navigator.onLine) return;
    setBuscandoFotos(true);
    try {
      const headers = await cabeceraAdmin(supabase);
      let vueltas = 0;
      let totales = { encontradas: 0, copiadas: 0, sinResultado: 0 };

      while (vueltas < 5) {
        const res = await fetch("/api/admin/completar-fotos", { method: "POST", headers });
        if (!res.ok) break;
        const r = await res.json();
        totales.encontradas += r.encontradas || 0;
        totales.copiadas += r.copiadas || 0;
        totales.sinResultado = r.sinResultado || 0;
        vueltas++;
        if (!r.faltan) break;
      }

      if (totales.encontradas > 0 || totales.copiadas > 0) cargarPedidos();

      if (conAviso) {
        setAvisoFotos(
          totales.sinResultado > 0
            ? `${totales.encontradas} fotos encontradas. ${totales.sinResultado} todavía no aparecen en el proveedor (puede estar en mantenimiento): se reintenta sola cada vez que entrás acá.`
            : `✓ Fotos completas${totales.copiadas ? ` (${totales.copiadas} guardadas en tu servidor)` : ""}.`
        );
      }
    } catch (e) {
      if (conAviso) setAvisoFotos("No se pudo buscar: " + e.message);
    } finally {
      setBuscandoFotos(false);
    }
  }

  useEffect(() => {
    cargarPedidos();
    completarFotos(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function interpretar() {
    if (!texto.trim()) return;
    setInterpretando(true);
    try {
      const res = await fetch("/api/admin/interpretar-pedido", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ texto })
      });
      const data = await res.json();

      if (!res.ok) {
        alert(data.error);
        return;
      }

      setItems(data.items);
      setSubtotal(data.subtotal);
    } finally {
      setInterpretando(false);
    }
  }

  function confirmarSugerido(i) {
    setItems((prev) =>
      prev.map((it, idx) =>
        idx === i ? { ...it, producto_id: it.sugerido.id, sugerido: null } : it
      )
    );
  }

  function descartarSugerido(i) {
    setItems((prev) =>
      prev.map((it, idx) => (idx === i ? { ...it, sugerido: null } : it))
    );
  }

  function quitarItem(i) {
    setItems((prev) => prev.filter((_, idx) => idx !== i));
  }

  async function guardarComoEnCamino() {
    if (items.length === 0) return;
    setGuardando(true);

    try {
      const { data: pedido, error } = await supabase
        .from("pedidos_proveedor")
        .insert({
          texto_original: texto,
          subtotal,
          flete: Number(flete) || 0,
          estado: "en_camino"
        })
        .select()
        .single();

      if (error) throw new Error(error.message);

      const lineas = items.map((i) => ({
        pedido_proveedor_id: pedido.id,
        producto_id: i.producto_id,
        nombre: i.nombre,
        cantidad: i.cantidad,
        precio_unitario: i.precio_unitario,
        imagen_url: i.imagen_url
      }));

      await supabase.from("lineas_pedido_proveedor").insert(lineas);

      const nuevos = items.filter((i) => !i.producto_id).length;

      alert(
        `✓ Pedido guardado como "en camino".\n\n` +
          `${items.length} productos van a mostrarse en "Llega pronto" ` +
          `(${nuevos} todavía sin precio, el resto con el precio que ya tenés).`
      );

      setTexto("");
      setFlete("");
      setItems([]);
      setSubtotal(0);
      setVista("camino");
      cargarPedidos();
      completarFotos(false);
    } catch (e) {
      alert("No se pudo guardar: " + e.message);
    } finally {
      setGuardando(false);
    }
  }

  async function borrarPedido(pedido) {
    if (
      !confirm(
        `¿Borrar este pedido con ${pedido.lineas_pedido_proveedor?.length || 0} productos?\n\n` +
          `No se toca el stock de nada, es solo sacarlo de la lista.`
      )
    )
      return;

    setBorrandoId(pedido.id);
    try {
      await supabase.from("pedidos_proveedor").delete().eq("id", pedido.id);
      cargarPedidos();
    } catch (e) {
      alert("No se pudo borrar: " + e.message);
    } finally {
      setBorrandoId(null);
    }
  }

  function empezarEdicion(pedido) {
    setEditando(pedido.id);
    setItemsEditando(
      (pedido.lineas_pedido_proveedor || []).map((l) => ({ ...l }))
    );
    setFleteEditando(pedido.flete || 0);
  }

  function cambiarCantidadEdicion(idx, valor) {
    setItemsEditando((prev) =>
      prev.map((it, i) => (i === idx ? { ...it, cantidad: Number(valor) || 0 } : it))
    );
  }

  function cambiarPrecioEdicion(idx, valor) {
    setItemsEditando((prev) =>
      prev.map((it, i) => (i === idx ? { ...it, precio_unitario: Number(valor) || 0 } : it))
    );
  }

  // Tipo de línea:
  //  - normal:     pagás el precio y ese es su costo
  //  - reposicion: llega sin cobrar (no vino en el pedido anterior, o vino roto
  //                y lo reponen). Pagás $0, y su costo sigue siendo lo que ya
  //                pagaste: así su precio de venta y tu ganancia no cambian.
  //  - cambio:     te lo cambiaron por otro y pagaste la diferencia. Pagás la
  //                diferencia, y su costo es el precio entero del producto nuevo.
  function cambiarTipoEdicion(idx, tipo) {
    setItemsEditando((prev) =>
      prev.map((it, i) => {
        if (i !== idx) return it;
        const costoConocido =
          Number(it.costo_real) || Number(it.precio_unitario) || Number(it.Productos?.costo) || 0;
        if (tipo === "normal") {
          return { ...it, tipo, precio_unitario: costoConocido, costo_real: null };
        }
        if (tipo === "reposicion") {
          return { ...it, tipo, costo_real: costoConocido, precio_unitario: 0 };
        }
        // cambio: arranca sin crédito; se completa cuánto tenías pagado
        return { ...it, tipo, costo_real: costoConocido, precio_unitario: costoConocido };
      })
    );
  }

  function cambiarCostoReal(idx, valor) {
    setItemsEditando((prev) =>
      prev.map((it, i) => {
        if (i !== idx) return it;
        const costo = Number(valor) || 0;
        if (it.tipo === "cambio") {
          // Mantiene el crédito que ya tenía y recalcula la diferencia
          const credito = Math.max(0, Number(it.costo_real || 0) - Number(it.precio_unitario || 0));
          return { ...it, costo_real: costo, precio_unitario: Math.max(0, costo - credito) };
        }
        return { ...it, costo_real: costo };
      })
    );
  }

  // En un cambio: cuánto ya habías pagado por el producto que no llegó
  function cambiarCredito(idx, valor) {
    setItemsEditando((prev) =>
      prev.map((it, i) =>
        i === idx
          ? { ...it, precio_unitario: Math.max(0, Number(it.costo_real || 0) - (Number(valor) || 0)) }
          : it
      )
    );
  }

  function cambiarNota(idx, valor) {
    setItemsEditando((prev) => prev.map((it, i) => (i === idx ? { ...it, nota: valor } : it)));
  }

  function quitarItemEdicion(idx) {
    setItemsEditando((prev) => prev.filter((_, i) => i !== idx));
  }

  async function guardarEdicion(pedido) {
    const sinCosto = itemsEditando.find((i) => (i.tipo || "normal") !== "normal" && !(Number(i.costo_real) > 0));
    if (sinCosto) {
      alert(
        `"${sinCosto.nombre_normalizado || sinCosto.nombre}" no tiene costo.\n\n` +
          "Indicá cuánto te costó (lo que pagaste antes), así su precio de venta y tu ganancia quedan bien."
      );
      return;
    }
    setGuardando(true);
    try {
      const existentes = itemsEditando.filter((i) => i.id);
      const nuevos = itemsEditando.filter((i) => !i.id);

      // Actualizamos las líneas que ya estaban
      for (const item of existentes) {
        const { error } = await supabase
          .from("lineas_pedido_proveedor")
          .update({
            cantidad: item.cantidad,
            precio_unitario: item.precio_unitario,
            tipo: item.tipo || "normal",
            costo_real: (item.tipo || "normal") === "normal" ? null : Number(item.costo_real) || null,
            nota: item.nota || null
          })
          .eq("id", item.id);
        if (error) throw new Error(error.message);
      }

      // Agregamos las nuevas. La base las vincula sola a un producto del
      // catálogo, o crea el producto si no existe todavía.
      if (nuevos.length > 0) {
        const { error } = await supabase.from("lineas_pedido_proveedor").insert(
          nuevos.map((i) => ({
            pedido_proveedor_id: pedido.id,
            producto_id: i.producto_id || null,
            nombre: i.nombre,
            cantidad: i.cantidad,
            precio_unitario: i.precio_unitario,
            tipo: i.tipo || "normal",
            costo_real: (i.tipo || "normal") === "normal" ? null : Number(i.costo_real) || null,
            nota: i.nota || null,
            imagen_url: i.imagen_url || null
          }))
        );
        if (error) throw new Error(error.message);
      }

      // Borramos las que se sacaron
      const idsQueQuedan = existentes.map((i) => i.id);
      const idsOriginales = (pedido.lineas_pedido_proveedor || []).map((i) => i.id);
      const aBorrar = idsOriginales.filter((id) => !idsQueQuedan.includes(id));

      if (aBorrar.length > 0) {
        const { error } = await supabase.from("lineas_pedido_proveedor").delete().in("id", aBorrar);
        if (error) throw new Error(error.message);
      }

      // Recalculamos el subtotal
      const nuevoSubtotal = itemsEditando.reduce(
        (a, i) => a + Number(i.cantidad || 0) * Number(i.precio_unitario || 0),
        0
      );
      const { error: errPedido } = await supabase
        .from("pedidos_proveedor")
        .update({ subtotal: nuevoSubtotal, flete: fleteEditando })
        .eq("id", pedido.id);
      if (errPedido) throw new Error(errPedido.message);

      setEditando(null);
      setItemsEditando([]);
      setBusquedaAgregar("");
      setResultadosAgregar([]);
      await cargarPedidos();
      if (nuevos.length > 0) completarFotos(false);
    } catch (e) {
      alert("No se pudo guardar: " + e.message);
    } finally {
      setGuardando(false);
    }
  }

  // ---------- AGREGAR PRODUCTOS A MANO ----------
  const [busquedaAgregar, setBusquedaAgregar] = useState("");
  const [resultadosAgregar, setResultadosAgregar] = useState([]);
  const [nombreLibre, setNombreLibre] = useState("");
  const [costoLibre, setCostoLibre] = useState("");

  // Busca en todo el catálogo: tus productos y los "a pedido"
  useEffect(() => {
    const q = busquedaAgregar.trim();
    if (q.length < 3) {
      setResultadosAgregar([]);
      return;
    }
    const t = setTimeout(async () => {
      const palabras = q.split(/\s+/).filter((w) => w.length >= 2).slice(0, 4);
      let consulta = supabase
        .from("Productos")
        .select("id, nombre, nombre_proveedor, costo, imagen_url, bajo_pedido, stock")
        .eq("activo", true)
        .limit(12);
      consulta = aplicarBusqueda(consulta, palabras.join(" "));
      const { data } = await consulta;
      setResultadosAgregar(data || []);
    }, 300);
    return () => clearTimeout(t);
  }, [busquedaAgregar]);

  function agregarDelCatalogo(prod) {
    setItemsEditando((prev) => {
      // Si ya está en el pedido, sumamos uno en vez de repetirlo
      const ya = prev.findIndex((i) => i.producto_id === prod.id);
      if (ya >= 0) {
        return prev.map((i, idx) =>
          idx === ya ? { ...i, cantidad: Number(i.cantidad || 0) + 1 } : i
        );
      }
      return [
        ...prev,
        {
          tmp: `n${Date.now()}`,
          producto_id: prod.id,
          nombre: prod.nombre_proveedor || prod.nombre,
          nombre_normalizado: prod.nombre,
          cantidad: 1,
          precio_unitario: Number(prod.costo || 0),
          imagen_url: null,
          Productos: { imagen_url: prod.imagen_url }
        }
      ];
    });
    setBusquedaAgregar("");
    setResultadosAgregar([]);
  }

  function agregarLibre() {
    const nombre = nombreLibre.trim();
    const costo = Number(costoLibre);
    if (nombre.length < 3 || !costo) {
      alert("Escribí el nombre tal cual figura en el proveedor y el costo.");
      return;
    }
    setItemsEditando((prev) => [
      ...prev,
      {
        tmp: `n${Date.now()}`,
        producto_id: null,
        nombre,
        nombre_normalizado: nombre,
        cantidad: 1,
        precio_unitario: costo,
        imagen_url: null
      }
    ]);
    setNombreLibre("");
    setCostoLibre("");
  }


  async function marcarRecibido(pedido) {
    if (
      !confirm(
        `¿Marcar como recibido "${pedido.numero_pedido || "este pedido"}"?\n\n` +
          `Se va a sumar el stock, actualizar precios y sacarlos de "Próximo pedido".`
      )
    )
      return;

    setRecibiendoId(pedido.id);
    try {
      const { data, error } = await supabase.rpc("recibir_pedido_proveedor", {
        p_pedido_id: pedido.id
      });

      if (error) throw new Error(error.message);

      const r = data?.[0];

      alert(
        `✓ Pedido recibido.\n\n` +
          `${r.productos_actualizados} productos actualizados\n` +
          `${r.productos_creados} productos nuevos creados`
      );

      cargarPedidos();
    } catch (e) {
      alert("No se pudo recibir: " + e.message);
    } finally {
      setRecibiendoId(null);
    }
  }

  const enCamino = pedidos.filter((p) => p.estado === "en_camino");
  const recibidos = pedidos.filter((p) => p.estado === "recibido");

  return (
    <main className="min-h-screen bg-gray-50 pb-16">
      <div className="max-w-2xl mx-auto px-4 py-6">
        <Link href="/admin" className="text-sm text-brand-blue font-medium">
          ← Panel
        </Link>
        <h1 className="text-2xl font-extrabold text-gray-800 mt-1 mb-1">
          Pedido al proveedor
        </h1>
        <p className="text-xs text-gray-500 mb-4">
          Pegá el texto tal cual sale de la web del proveedor.
        </p>

        <div className="flex gap-2 mb-4">
          {[
            { id: "nuevo", label: "📋 Cargar" },
            { id: "camino", label: `🚚 En camino (${enCamino.length})` },
            { id: "recibidos", label: `✅ Recibidos (${recibidos.length})` }
          ].map((v) => (
            <button
              key={v.id}
              onClick={() => setVista(v.id)}
              className={`flex-1 py-2 rounded-xl text-[11px] font-bold ${
                vista === v.id
                  ? "bg-brand-blue text-white"
                  : "bg-white border border-gray-200 text-gray-600"
              }`}
            >
              {v.label}
            </button>
          ))}
        </div>

        {vista === "nuevo" && (
          <>
            <div className="bg-white rounded-2xl border-2 border-brand-blue p-4 mb-4">
              <p className="text-xs font-bold text-gray-700 mb-2">
                Pegá el detalle del pedido
              </p>
              <textarea
                value={texto}
                onChange={(e) => setTexto(e.target.value)}
                rows={8}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-xs font-mono"
                placeholder={
                  "Rollo Vinilo Blanco Con Gris WMA-003 60x200cm × 2\t$9.200,00\n" +
                  "Toalla De Algodon De Baño 40x70Cm Blanco Oriental TOA-YW1 × 3\t$9.000,00\n" +
                  "..."
                }
              />

              <button
                onClick={interpretar}
                disabled={interpretando || !texto.trim()}
                className="w-full bg-brand-blue text-white text-sm font-bold py-2.5 rounded-xl mt-2 disabled:opacity-50"
              >
                {interpretando ? "Buscando fotos..." : "Interpretar pedido"}
              </button>
            </div>

            {items.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 p-4 mb-4">
                <p className="text-sm font-bold text-gray-800 mb-1">
                  {items.length} productos · ${formatPrice(subtotal)}
                </p>
                <p className="text-[11px] text-gray-500 mb-3">
                  Revisá que esté bien antes de guardar. Podés sacar los que sobren.
                </p>

                <div className="space-y-2 max-h-96 overflow-y-auto mb-3">
                  {items.map((i, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 border-b border-gray-50 pb-2"
                    >
                      <div className="w-10 h-10 bg-gray-50 rounded-lg overflow-hidden flex-shrink-0 flex items-center justify-center">
                        {i.imagen_url ? (
                          <img src={i.imagen_url} alt="" className="w-full h-full object-contain" />
                        ) : (
                          <span className="text-sm">📦</span>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-semibold text-gray-800 line-clamp-1">
                          {i.nombre}
                        </p>
                        <p className="text-[10px] text-gray-500">
                          {i.cantidad}x ${formatPrice(i.precio_unitario)}
                          {i.producto_id && (
                            <span className="text-green-700 font-bold"> · ya lo tenés</span>
                          )}
                          {!i.imagen_url && (
                            <span className="text-amber-700 font-bold"> · sin foto</span>
                          )}
                        </p>

                        {i.sugerido && (
                          <div className="bg-amber-50 border border-amber-300 rounded-lg p-1.5 mt-1">
                            <p className="text-[10px] text-amber-800">
                              ¿Es lo mismo que <b>{i.sugerido.nombre}</b>?
                            </p>
                            <div className="flex gap-1.5 mt-1">
                              <button
                                onClick={() => confirmarSugerido(idx)}
                                className="text-[10px] font-bold bg-amber-600 text-white px-2 py-0.5 rounded"
                              >
                                Sí, es este
                              </button>
                              <button
                                onClick={() => descartarSugerido(idx)}
                                className="text-[10px] font-bold text-gray-500 px-2 py-0.5"
                              >
                                No, es nuevo
                              </button>
                            </div>
                          </div>
                        )}
                      </div>

                      <button
                        onClick={() => quitarItem(idx)}
                        className="text-red-500 text-sm font-bold px-1"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>

                <label className="text-xs font-bold text-gray-600 block mb-1">
                  Flete (estimado si todavía no lo sabés)
                </label>
                <input
                  type="number"
                  value={flete}
                  onChange={(e) => setFlete(e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm mb-3"
                  placeholder="$"
                />

                <button
                  onClick={guardarComoEnCamino}
                  disabled={guardando}
                  className="w-full bg-amber-600 text-white text-sm font-bold py-3 rounded-xl disabled:opacity-50"
                >
                  {guardando ? "Guardando..." : "🚚 Guardar como \"en camino\""}
                </button>

                <p className="text-[10px] text-gray-500 mt-2 text-center">
                  Los productos nuevos van a mostrarse sin precio en &quot;Llega pronto&quot;
                </p>
              </div>
            )}
          </>
        )}

        {vista === "camino" && (
          <div className="space-y-3">
            <button
              onClick={() => completarFotos(true)}
              disabled={buscandoFotos}
              className="w-full bg-white border-2 border-brand-blue text-brand-blue text-xs font-bold py-2.5 rounded-xl disabled:opacity-50"
            >
              {buscandoFotos ? "Buscando fotos en el proveedor..." : "🔍 Completar fotos desde el proveedor"}
            </button>

            {avisoFotos && (
              <p className="text-[11px] font-semibold text-gray-700 bg-white border border-gray-200 rounded-xl p-2.5">
                {avisoFotos}
              </p>
            )}
            {loading ? (
              <p className="text-center text-gray-400 py-10">Cargando...</p>
            ) : enCamino.length === 0 ? (
              <div className="bg-white rounded-2xl p-6 text-center border border-gray-100">
                <p className="text-sm text-gray-600">No hay pedidos en camino.</p>
              </div>
            ) : (
              enCamino.map((p) => (
                <div key={p.id} className="bg-white rounded-2xl border-2 border-amber-300 p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="text-sm font-bold text-gray-800">
                        Pedido {p.numero_pedido || "#" + p.id} ·{" "}
                        {new Date(p.fecha_pedido).toLocaleDateString("es-AR")}
                      </p>
                      <p className="text-[11px] text-gray-500">
                        {p.lineas_pedido_proveedor?.length || 0} productos · $
                        {formatPrice(p.subtotal)}
                        {p.flete > 0 ? ` + $${formatPrice(p.flete)} flete` : " · flete sin confirmar"}
                      </p>
                      {(() => {
                        const especiales = (p.lineas_pedido_proveedor || []).filter((l) => (l.tipo || "normal") !== "normal");
                        if (!especiales.length) return null;
                        const repo = especiales.filter((l) => l.tipo === "reposicion").length;
                        const camb = especiales.filter((l) => l.tipo === "cambio").length;
                        const yaPagado = especiales.reduce(
                          (a, l) => a + (Number(l.costo_real || 0) - Number(l.precio_unitario || 0)) * Number(l.cantidad || 0),
                          0
                        );
                        return (
                          <p className="text-[11px] font-bold text-purple-700 mt-0.5">
                            {repo > 0 && `🔁 ${repo} reposición${repo > 1 ? "es" : ""}`}
                            {repo > 0 && camb > 0 && " · "}
                            {camb > 0 && `🔄 ${camb} cambio${camb > 1 ? "s" : ""}`} · ya pagado antes: ${formatPrice(yaPagado)}
                          </p>
                        );
                      })()}
                      {(p.lineas_pedido_proveedor || []).filter((l) => !fotoDeLinea(l)).length > 0 && (
                        <p className="text-[11px] font-bold text-amber-700 mt-0.5">
                          📷 {(p.lineas_pedido_proveedor || []).filter((l) => !fotoDeLinea(l)).length} sin foto
                          — tocá Editar para agregarla
                        </p>
                      )}
                    </div>
                  </div>

                  {editando === p.id ? (
                    <div className="border-t border-gray-100 pt-3 mt-2">
                      <div className="space-y-2 max-h-80 overflow-y-auto mb-3">
                        {itemsEditando.map((item, idx) => (
                          <div key={item.id || item.tmp} className="flex items-center gap-2 border-b border-gray-50 pb-2">
                            <label
                              className={`w-11 h-11 rounded-lg overflow-hidden flex-shrink-0 flex items-center justify-center cursor-pointer ${
                                fotoDeLinea(item) ? "bg-gray-50" : "bg-amber-50 border-2 border-dashed border-amber-400"
                              }`}
                            >
                              {subiendoFotoLinea === item.id ? (
                                <span className="text-[10px]">...</span>
                              ) : fotoDeLinea(item) ? (
                                <img src={fotoDeLinea(item)} alt="" className="w-full h-full object-contain" />
                              ) : (
                                <span className="text-[9px] font-bold text-amber-700 text-center leading-tight">
                                  📷
                                  <br />
                                  foto
                                </span>
                              )}
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                disabled={!item.id || subiendoFotoLinea === item.id}
                                onChange={(e) => subirFotoLinea(item, e.target.files?.[0])}
                              />
                            </label>
                            <div className="flex-1 min-w-0">
                              <p className="text-[11px] font-semibold text-gray-800 line-clamp-2">
                                {item.nombre_normalizado || item.nombre}
                              </p>
                              {!item.id ? (
                                <p className="text-[9px] font-bold text-green-700">
                                  AGREGADO · se guarda al tocar Guardar cambios
                                </p>
                              ) : (
                                !item.producto_id && (
                                  <p className="text-[9px] font-bold text-amber-700">NUEVO</p>
                                )
                              )}

                              {/* Tipo de línea */}
                              <div className="flex gap-1 mt-1">
                                {[
                                  { id: "normal", label: "Normal" },
                                  { id: "reposicion", label: "🔁 Reposición" },
                                  { id: "cambio", label: "🔄 Cambio" }
                                ].map((op) => (
                                  <button
                                    key={op.id}
                                    type="button"
                                    onClick={() => cambiarTipoEdicion(idx, op.id)}
                                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md border ${
                                      (item.tipo || "normal") === op.id
                                        ? op.id === "normal"
                                          ? "bg-gray-700 text-white border-gray-700"
                                          : "bg-purple-600 text-white border-purple-600"
                                        : "bg-white text-gray-500 border-gray-200"
                                    }`}
                                  >
                                    {op.label}
                                  </button>
                                ))}
                              </div>

                              {item.tipo === "reposicion" && (
                                <div className="bg-purple-50 rounded-lg p-1.5 mt-1">
                                  <p className="text-[9px] text-purple-900">
                                    Llega sin cobrar (no vino antes o vino roto). <b>Pagás $0</b>; el costo sigue siendo
                                    lo que ya pagaste:
                                  </p>
                                  <label className="flex items-center gap-1 mt-0.5 text-[10px] font-bold text-purple-900">
                                    Te costó $
                                    <input
                                      type="number"
                                      value={item.costo_real ?? ""}
                                      onChange={(e) => cambiarCostoReal(idx, e.target.value)}
                                      className="w-20 border border-purple-200 rounded px-1.5 py-0.5 text-[11px] bg-white"
                                    />
                                  </label>
                                </div>
                              )}

                              {item.tipo === "cambio" && (
                                <div className="bg-purple-50 rounded-lg p-1.5 mt-1 space-y-0.5">
                                  <label className="flex items-center gap-1 text-[10px] font-bold text-purple-900">
                                    Precio del nuevo $
                                    <input
                                      type="number"
                                      value={item.costo_real ?? ""}
                                      onChange={(e) => cambiarCostoReal(idx, e.target.value)}
                                      className="w-20 border border-purple-200 rounded px-1.5 py-0.5 text-[11px] bg-white"
                                    />
                                  </label>
                                  <label className="flex items-center gap-1 text-[10px] font-bold text-purple-900">
                                    Ya tenías pagado $
                                    <input
                                      type="number"
                                      value={Math.max(0, Number(item.costo_real || 0) - Number(item.precio_unitario || 0))}
                                      onChange={(e) => cambiarCredito(idx, e.target.value)}
                                      className="w-20 border border-purple-200 rounded px-1.5 py-0.5 text-[11px] bg-white"
                                    />
                                  </label>
                                  <input
                                    value={item.nota || ""}
                                    onChange={(e) => cambiarNota(idx, e.target.value)}
                                    placeholder="Reemplaza a... (ej: Estante 3 Niveles)"
                                    className="w-full border border-purple-200 rounded px-1.5 py-0.5 text-[10px] bg-white"
                                  />
                                  <p className="text-[10px] font-extrabold text-purple-900">
                                    Pagás la diferencia: ${formatPrice(item.precio_unitario || 0)}
                                  </p>
                                </div>
                              )}
                            </div>
                            <input
                              type="number"
                              value={item.cantidad}
                              onChange={(e) => cambiarCantidadEdicion(idx, e.target.value)}
                              className="w-14 border border-gray-200 rounded-lg px-2 py-1 text-xs text-center"
                            />
                            {(item.tipo || "normal") === "normal" ? (
                              <input
                                type="number"
                                value={item.precio_unitario}
                                onChange={(e) => cambiarPrecioEdicion(idx, e.target.value)}
                                className="w-20 border border-gray-200 rounded-lg px-2 py-1 text-xs text-center"
                              />
                            ) : (
                              <span className="w-20 text-center text-[10px] font-bold text-purple-700">
                                paga ${formatPrice(item.precio_unitario || 0)}
                              </span>
                            )}
                            <button
                              onClick={() => quitarItemEdicion(idx)}
                              className="text-red-500 text-sm font-bold px-1"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>

                      {/* Agregar productos a mano */}
                      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3">
                        <p className="text-xs font-bold text-gray-800 mb-1.5">➕ Agregar producto</p>

                        <input
                          value={busquedaAgregar}
                          onChange={(e) => setBusquedaAgregar(e.target.value)}
                          placeholder="Buscar en tu catálogo (tuyos y a pedido)..."
                          className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white"
                        />

                        {resultadosAgregar.length > 0 && (
                          <div className="bg-white rounded-lg border border-gray-200 mt-1.5 max-h-64 overflow-y-auto">
                            {resultadosAgregar.map((r) => (
                              <button
                                key={r.id}
                                type="button"
                                onClick={() => agregarDelCatalogo(r)}
                                className="w-full flex items-center gap-2 p-2 border-b border-gray-50 text-left"
                              >
                                <div className="w-9 h-9 bg-gray-50 rounded overflow-hidden flex-shrink-0">
                                  {r.imagen_url && (
                                    <img src={r.imagen_url} alt="" className="w-full h-full object-contain" />
                                  )}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-[11px] font-semibold text-gray-800 line-clamp-1">{r.nombre}</p>
                                  <p className="text-[10px] text-gray-500">
                                    {r.bajo_pedido ? "A pedido" : `Tuyo · stock ${r.stock || 0}`} · costo $
                                    {formatPrice(r.costo || 0)}
                                  </p>
                                </div>
                                <span className="text-brand-blue text-lg font-bold">+</span>
                              </button>
                            ))}
                          </div>
                        )}

                        {busquedaAgregar.trim().length >= 3 && resultadosAgregar.length === 0 && (
                          <p className="text-[10px] text-gray-500 mt-1">No está en tu catálogo. Cargalo abajo.</p>
                        )}

                        <p className="text-[10px] font-bold text-gray-600 mt-3 mb-1">
                          ¿No está en tu catálogo? Pegá el nombre tal cual del proveedor:
                        </p>
                        <input
                          value={nombreLibre}
                          onChange={(e) => setNombreLibre(e.target.value)}
                          placeholder="Ej: Kit Manicura Pedicura Estuche Cuero S-2406"
                          className="w-full border border-gray-200 rounded-lg px-3 py-2 text-xs bg-white mb-1.5"
                        />
                        <div className="flex gap-2">
                          <input
                            type="number"
                            value={costoLibre}
                            onChange={(e) => setCostoLibre(e.target.value)}
                            placeholder="Costo $"
                            className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-xs bg-white"
                          />
                          <button
                            type="button"
                            onClick={agregarLibre}
                            className="bg-brand-blue text-white text-xs font-bold px-4 rounded-lg"
                          >
                            Agregar
                          </button>
                        </div>
                        <p className="text-[10px] text-gray-500 mt-1.5">
                          Se crea solo en tu catálogo como &quot;a pedido&quot;, con la foto del proveedor.
                        </p>
                      </div>

                      <label className="text-xs font-bold text-gray-600 block mb-1">
                        Flete de este pedido
                      </label>
                      <input
                        type="number"
                        value={fleteEditando}
                        onChange={(e) => setFleteEditando(Number(e.target.value) || 0)}
                        className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm mb-3"
                        placeholder="$"
                      />

                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            setEditando(null);
                            setItemsEditando([]);
                          }}
                          className="px-4 text-xs font-bold text-gray-500"
                        >
                          Cancelar
                        </button>
                        <button
                          onClick={() => guardarEdicion(p)}
                          disabled={guardando}
                          className="flex-1 bg-brand-blue text-white text-sm font-bold py-2.5 rounded-xl disabled:opacity-50"
                        >
                          {guardando ? "Guardando..." : "Guardar cambios"}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="flex gap-2 mb-2">
                        <button
                          onClick={() => empezarEdicion(p)}
                          className="flex-1 bg-white border-2 border-brand-blue text-brand-blue text-xs font-bold py-2.5 rounded-xl"
                        >
                          ✏️ Editar
                        </button>
                        <button
                          onClick={() => borrarPedido(p)}
                          disabled={borrandoId === p.id}
                          className="px-4 bg-white border-2 border-red-300 text-red-600 text-xs font-bold rounded-xl disabled:opacity-50"
                        >
                          {borrandoId === p.id ? "..." : "🗑️"}
                        </button>
                      </div>

                      <button
                        onClick={() => marcarRecibido(p)}
                        disabled={recibiendoId === p.id}
                        className="w-full bg-green-600 text-white text-sm font-bold py-3 rounded-xl disabled:opacity-50"
                      >
                        {recibiendoId === p.id ? "Cargando..." : "✅ Marcar como llegado"}
                      </button>
                    </>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {vista === "recibidos" && (
          <div className="space-y-2">
            {recibidos.length === 0 ? (
              <div className="bg-white rounded-2xl p-6 text-center border border-gray-100">
                <p className="text-sm text-gray-600">Todavía no recibiste ninguno.</p>
              </div>
            ) : (
              recibidos.map((p) => (
                <DetallePedidoRecibido key={p.id} pedido={p} onActualizado={cargarPedidos} />
              ))
            )}
          </div>
        )}
      </div>
    </main>
  );
}

export default function PedidoProveedorPage() {
  return (
    <AdminGuard>
      <PedidoProveedor />
    </AdminGuard>
  );
}
